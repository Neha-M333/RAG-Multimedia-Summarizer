"""
Upload Documents Page - FIXED
Streamlit multipage component for document upload
"""
import streamlit as st
import os
import sys
from pathlib import Path

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent))

from backend.document_processor import DocumentProcessor
from backend.database_manager import EnhancedDatabaseManager
from backend.rag_engine import AdvancedRAGEngine, QueryComplexity  # FIXED: AdvancedRAGEngine
from utils.config import Config
from backend.local_llm import LocalRAGEngine
from backend.chat_metrics_logger import ChatMetricsLogger

st.set_page_config(
    page_title="Upload Documents",
    page_icon="📤",
    layout="wide"
)

# Initialize session state
if 'processed_docs' not in st.session_state:
    st.session_state.processed_docs = []

# Initialize components
@st.cache_resource
def init_components():
    processor = DocumentProcessor()
    db_manager = EnhancedDatabaseManager(
        str(Config.db_config.sqlite_path),
        str(Config.db_config.chromadb_path)
    )
    
    # Check if using local LLM or OpenAI
    if Config.USE_LOCAL_LLM:
        # Use local LLM - no API key needed
        from backend.local_llm import LocalRAGEngine
        rag_engine = LocalRAGEngine(model=Config.OLLAMA_MODEL)
        return processor, db_manager, rag_engine
    else:
        # Use OpenAI - need API key
        api_key = Config.OPENAI_API_KEY
        if not api_key or api_key.startswith('sk-your'):
            return None, None, None
        
        rag_engine = AdvancedRAGEngine(api_key, Config.model_config.model_name)
        return processor, db_manager, rag_engine
processor, db_manager, rag_engine = init_components()
# Initialize metrics logger
metrics_logger = ChatMetricsLogger("data/chat_metrics_log.xlsx")

# Page header
st.markdown("# 📤 Upload & Process Documents")
st.markdown("Upload PDFs, Excel files, audio, or video files for processing")

if not processor or not db_manager or not rag_engine:
    if Config.USE_LOCAL_LLM:
        st.error("❌ System not initialized. Please check if Ollama is running.")
        st.info("💡 Start Ollama: `ollama serve` in terminal")
    else:
        st.error("❌ System not initialized. Please check your API key in .env file.")
    st.stop()

# File uploader
st.markdown("---")
st.markdown("### Select Files to Upload")

uploaded_files = st.file_uploader(
    "Choose files to upload",
    type=[
        # Documents
        'pdf', 'docx', 'doc', 'pptx', 'ppt', #'rtf',
        # Spreadsheets
        'xlsx', 'xls', 'csv',
        # Code & Data
        'py', 'js', 'java', 'c',# 'cpp', 'cs', 'php', 'rb', 'go', 'rs', 'swift',
        'json', 'xml',
        # Web & Text
        'html', 'txt', 'md', #'markdown', 'htm', 'log',
        # Media - Audio
        'mp3', #'wav', 'm4a', 'flac', 'ogg', 'aac',
        # Media - Video
        'mp4', #'avi', 'mov', 'mkv', 'flv', 'wmv',
        # Media - Images
        'jpg', 'jpeg', 'png', 'gif', #'bmp', 'tiff', 'webp',
        # E-books
        #'epub'
    ],
    accept_multiple_files=True,
    help="Supported: Documents (PDF, Word, PowerPoint, RTF), Spreadsheets (Excel, CSV), Code (Python, JavaScript, Java, C++, etc.), Media (Audio, Video, Images), Web (HTML, Markdown), Data (JSON, XML), E-books (EPUB)"
)   

if uploaded_files:
    st.success(f"✅ {len(uploaded_files)} file(s) selected")
    
    # Display file information
    st.markdown("### 📋 Selected Files")
    
    for idx, file in enumerate(uploaded_files, 1):
        col1, col2, col3, col4 = st.columns([1, 3, 2, 2])
        
        with col1:
            st.write(f"**{idx}.**")
        with col2:
            st.write(f"📄 {file.name}")
        with col3:
            st.write(f"Size: {file.size / 1024:.2f} KB")
        with col4:
            file_ext = Path(file.name).suffix.lower()
            if file_ext == '.pdf':
                st.write("📄 PDF")
            elif file_ext in ['.xlsx', '.xls', '.csv']:
                st.write("📊 Excel/CSV")
            elif file_ext in ['.mp3', '.wav', '.m4a']:
                st.write("🎵 Audio")
            elif file_ext in ['.mp4', '.avi', '.mov']:
                st.write("🎬 Video")
    
    st.markdown("---")
    
    # Processing options
    col1, col2 = st.columns([3, 1])
    
    with col1:
        st.markdown("### ⚙️ Processing Options")
        generate_summary = st.checkbox("Generate automatic summaries", value=True)
        extract_keywords = st.checkbox("Extract keywords", value=False)
    
    with col2:
        st.markdown("### ")
        st.markdown("### ")
        
    # Process button
    if st.button("🚀 Process Documents", type="primary", use_container_width=True):
        progress_bar = st.progress(0)
        status_container = st.container()
        
        with status_container:
            for idx, file in enumerate(uploaded_files):
                # Start metrics tracking for this file
                file_session_id = f"{st.session_state.get('session_id', 'session')}_file_{idx}"
                metrics_logger.start_session(file_session_id)
                
                with st.status(f"Processing {file.name}...", expanded=True) as status:
                    try:
                        # === PHASE 1: FILE LOADING ===
                        st.write(f"💾 Saving file...")
                        with metrics_logger.track_phase('file_load'):
                            temp_path = Config.UPLOADS_DIR / file.name
                            with open(temp_path, "wb") as f:
                                f.write(file.getbuffer())
                            
                            # Determine file type
                            file_ext = Path(file.name).suffix.lower()
                            if file_ext == '.pdf':
                                file_type = 'pdf'
                            elif file_ext in ['.xlsx', '.xls', '.csv']:
                                file_type = 'excel'
                            elif file_ext in ['.mp3', '.wav', '.m4a', '.ogg']:
                                file_type = 'audio'
                            elif file_ext in ['.mp4', '.avi', '.mov', '.mkv']:
                                file_type = 'video'
                            else:
                                st.warning(f"⚠️ Unsupported file type: {file.name}")
                                metrics_logger.log_error(f"Unsupported file type: {file_ext}")
                                metrics_logger.end_session()
                                continue
                        
                        # === PHASE 2: PROCESSING ===
                        st.write(f"🔎 Extracting content...")
                        with metrics_logger.track_phase('processing'):
                            result = processor.process_document(str(temp_path), file_type)
                            full_text = result['full_text']
                            words_count = len(full_text.split())
                        
                        # Log file information
                        metrics_logger.log_file_info(
                            file_name=file.name,
                            file_type=file_type,
                            file_size_bytes=file.size,
                            words_count=words_count,
                            chunks_count=0  # Will update after chunking
                        )
                        
                        st.write(f"💾 Saving to database...")
                        doc_id = db_manager.add_document(
                            file.name,
                            file_type,
                            result['metadata']
                        )
                        
                        # === PHASE 3: EMBEDDING ===
                        st.write(f"🔪 Chunking text...")
                        with metrics_logger.track_phase('embedding'):
                            chunks = rag_engine.chunk_text_adaptive(
                                result['full_text'],
                                metadata={'file_name': file.name, 'file_type': file_type}
                            )
                        
                        st.write(f"🔗 Adding to vector database...")
                        db_manager.add_chunks_to_vector_db(
                            doc_id,
                            [c['content'] for c in chunks],
                            [c['metadata'] for c in chunks]
                        )
                        
                        # Update chunks count
                        metrics_logger.current_metrics['chunks_count'] = len(chunks)
                        
                        db_manager.mark_document_processed(doc_id)
                        
                        # Generate summary if requested
                        summary = None
                        if generate_summary:
                            st.write(f"📊 Generating summary...")
                            summary_result = rag_engine.summarize_advanced(
                                result['full_text'][:5000],
                                style="executive",
                                language="English",
                                target_length=300
                            )
                            summary = summary_result['summary']
                            db_manager.save_summary(doc_id, summary, "en")
                        
                        # Extract keywords if requested
                        keywords = None
                        if extract_keywords:
                            st.write(f"🔑 Extracting keywords...")
                            keywords = rag_engine.extract_keywords(
                                result['full_text'][:3000],
                                num_keywords=10
                            )
                        
                        st.session_state.processed_docs.append({
                            'id': doc_id,
                            'name': file.name,
                            'type': file_type,
                            'summary': summary,
                            'keywords': keywords,
                            'chunks': len(chunks)
                        })
                        
                        # Clean up
                        os.remove(temp_path)
                        
                        # End successful session
                        metrics_logger.end_session()
                        
                        status.update(label=f"✅ {file.name} processed successfully!", 
                                    state="complete", expanded=False)
                        
                    except Exception as e:
                        # Log error
                        metrics_logger.log_error(str(e))
                        metrics_logger.end_session()
                        
                        status.update(label=f"❌ Error processing {file.name}", 
                                    state="error", expanded=True)
                        st.error(f"Error: {str(e)}")
                
                progress_bar.progress((idx + 1) / len(uploaded_files))
        
        st.success(f"🎉 Successfully processed {len(uploaded_files)} document(s)!")
        
        # Display processing results
        if st.session_state.processed_docs:
            st.markdown("---")
            st.markdown("### 📊 Processing Results")
            
            for doc in st.session_state.processed_docs:
                with st.expander(f"📄 {doc['name']}", expanded=True):
                    col1, col2 = st.columns([1, 3])
                    
                    with col1:
                        st.metric("Document ID", doc['id'])
                        st.metric("Type", doc['type'].upper())
                        st.metric("Chunks Created", doc['chunks'])
                    
                    with col2:
                        if doc['summary']:
                            st.markdown("**Summary:**")
                            st.write(doc['summary'])
                        
                        if doc['keywords']:
                            st.markdown("**Keywords:**")
                            st.write(", ".join(doc['keywords']))

# Show existing documents
st.markdown("---")
st.markdown("### 📚 Document Library")

if db_manager:
    docs = db_manager.get_all_documents()
    
    if docs:
        # Create a dataframe for better display
        import pandas as pd
        
        docs_df = pd.DataFrame([
            {
                'ID': doc['id'],
                'File Name': doc['file_name'],
                'Type': doc['file_type'].upper(),
                'Upload Date': doc['upload_date'][:10],
                'Pages/Rows': str(doc['metadata'].get('pages', doc['metadata'].get('rows', 'N/A')))
            }
            for doc in docs
        ])

        # Ensure all columns are proper types
        docs_df['ID'] = docs_df['ID'].astype(str)
        docs_df['Pages/Rows'] = docs_df['Pages/Rows'].astype(str)
        
        st.dataframe(docs_df, use_container_width=True, hide_index=True)
        
        # Delete functionality
        st.markdown("#### 🗑️ Delete Documents")
        doc_to_delete = st.selectbox(
            "Select document to delete",
            options=[f"{doc['id']} - {doc['file_name']}" for doc in docs],
            key="delete_select"
        )
        
        col1, col2, col3 = st.columns([1, 1, 4])
        with col1:
            if st.button("Delete Selected", type="secondary", use_container_width=True):
                doc_id = int(doc_to_delete.split(' - ')[0])
                db_manager.delete_document(doc_id)
                st.success("Document deleted!")
                st.rerun()
        
        with col2:
            if st.button("Clear All", type="secondary"):
                if st.checkbox("Confirm deletion of all documents"):
                    for doc in docs:
                        db_manager.delete_document(doc['id'])
                    st.success("All documents deleted!")
                    st.rerun()
    else:
        st.info("🔭 No documents uploaded yet. Upload some files to get started!")

# Footer
st.markdown("---")
st.markdown("""
<div style='text-align: center; color: #666; padding: 1rem;'>
    <p>💡 Tip: Upload multiple files at once for batch processing</p>
    <p>Supported formats: PDF, Excel, CSV, Audio (MP3, WAV, M4A), Video (MP4, AVI, MOV)</p>
</div>
""", unsafe_allow_html=True)