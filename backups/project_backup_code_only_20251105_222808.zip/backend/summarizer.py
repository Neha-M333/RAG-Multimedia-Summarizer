"""
Advanced Text Summarization Module
Provides various summarization techniques and strategies
"""

from typing import List, Dict, Optional, Literal
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain_community.chat_models import ChatOpenAI
import openai

class Summarizer:
    def __init__(self, api_key: str, model: str = "gpt-3.5-turbo"):
        self.api_key = api_key
        self.model = model
        openai.api_key = api_key
        
        # Initialize LLM
        self.llm = ChatOpenAI(
            model=model,
            temperature=0.3,  # Lower temperature for more focused summaries
            openai_api_key=api_key
        )
        
        # Text splitter for long documents
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=3000,
            chunk_overlap=200,
            separators=["\n\n", "\n", " ", ""]
        )
    
    def summarize(
        self,
        text: str,
        style: Literal["concise", "detailed", "bullet_points", "executive"] = "concise",
        language: str = "English",
        max_length: int = 500
    ) -> Dict:
        """
        Generate a summary with specified style
        
        Args:
            text: Text to summarize
            style: Summarization style
            language: Target language
            max_length: Maximum length in words
        
        Returns:
            Dictionary with summary and metadata
        """
        # For very long texts, use map-reduce strategy
        if len(text.split()) > 3000:
            return self._summarize_long_text(text, style, language, max_length)
        else:
            return self._summarize_short_text(text, style, language, max_length)
    
    def _summarize_short_text(
        self,
        text: str,
        style: str,
        language: str,
        max_length: int
    ) -> Dict:
        """Summarize shorter texts directly"""
        
        style_prompts = {
            "concise": "Create a brief, concise summary",
            "detailed": "Create a comprehensive, detailed summary",
            "bullet_points": "Create a summary in bullet point format with key points",
            "executive": "Create an executive summary suitable for business stakeholders"
        }
        
        prompt_template = """{instruction} of the following text in {language}.
Keep it around {max_length} words.

Text:
{text}

Summary:"""

        prompt = PromptTemplate(
            template=prompt_template,
            input_variables=["instruction", "text", "language", "max_length"]
        )
        
        chain = LLMChain(llm=self.llm, prompt=prompt)
        
        summary = chain.run(
            instruction=style_prompts[style],
            text=text[:10000],  # Limit to avoid token limits
            language=language,
            max_length=max_length
        )
        
        return {
            'summary': summary.strip(),
            'style': style,
            'language': language,
            'word_count': len(summary.split()),
            'method': 'direct'
        }
    
    def _summarize_long_text(
        self,
        text: str,
        style: str,
        language: str,
        max_length: int
    ) -> Dict:
        """Summarize long texts using map-reduce strategy"""
        
        # Split text into chunks
        chunks = self.text_splitter.split_text(text)
        
        # Summarize each chunk
        chunk_summaries = []
        for i, chunk in enumerate(chunks):
            prompt = f"""Summarize this section concisely:

{chunk}

Summary:"""
            
            response = self.llm.predict(prompt)
            chunk_summaries.append(response.strip())
        
        # Combine chunk summaries
        combined_summary = " ".join(chunk_summaries)
        
        # Final summarization
        final_result = self._summarize_short_text(
            combined_summary,
            style,
            language,
            max_length
        )
        
        final_result['method'] = 'map_reduce'
        final_result['chunks_processed'] = len(chunks)
        
        return final_result
    
    def summarize_multiple_documents(
        self,
        documents: List[Dict],
        style: str = "concise",
        language: str = "English"
    ) -> Dict:
        """
        Create a consolidated summary from multiple documents
        
        Args:
            documents: List of dicts with 'title' and 'content'
            style: Summarization style
            language: Target language
        
        Returns:
            Consolidated summary
        """
        # Summarize each document first
        doc_summaries = []
        
        for doc in documents:
            summary_result = self.summarize(
                text=doc['content'],
                style="concise",
                language=language,
                max_length=200
            )
            
            doc_summaries.append({
                'title': doc.get('title', 'Untitled'),
                'summary': summary_result['summary']
            })
        
        # Create consolidated summary
        combined_text = "\n\n".join([
            f"Document: {ds['title']}\n{ds['summary']}"
            for ds in doc_summaries
        ])
        
        prompt = f"""Create a consolidated {style} summary of these document summaries in {language}:

{combined_text}

Consolidated Summary:"""
        
        final_summary = self.llm.predict(prompt)
        
        return {
            'summary': final_summary.strip(),
            'documents_processed': len(documents),
            'individual_summaries': doc_summaries,
            'style': style,
            'language': language
        }
    
    def extract_key_points(self, text: str, num_points: int = 5) -> List[str]:
        """Extract key points from text"""
        
        prompt = f"""Extract the {num_points} most important key points from this text.
Return each point on a new line, numbered.

Text:
{text[:5000]}

Key Points:"""
        
        response = self.llm.predict(prompt)
        
        # Parse the response into a list
        points = [line.strip() for line in response.split('\n') if line.strip()]
        return points[:num_points]
    
    def generate_abstract(self, text: str, max_words: int = 250) -> str:
        """Generate an academic-style abstract"""
        
        prompt = f"""Generate an academic abstract (maximum {max_words} words) for this text.
Include: purpose, methodology, key findings, and conclusions.

Text:
{text[:8000]}

Abstract:"""
        
        abstract = self.llm.predict(prompt)
        return abstract.strip()
    
    def summarize_by_sections(self, text: str, sections: List[str]) -> Dict:
        """
        Summarize text focusing on specific sections/topics
        
        Args:
            text: Full text
            sections: List of section topics to focus on
        
        Returns:
            Dict with summaries for each section
        """
        summaries = {}
        
        for section in sections:
            prompt = f"""From the following text, summarize information related to: {section}

Text:
{text[:8000]}

Summary of {section}:"""
            
            summary = self.llm.predict(prompt)
            summaries[section] = summary.strip()
        
        return summaries
    
    def compare_documents(self, doc1: str, doc2: str) -> Dict:
        """Compare two documents and summarize differences"""
        
        prompt = f"""Compare these two documents and summarize:
1. Main similarities
2. Key differences
3. Unique points in each document

Document 1:
{doc1[:3000]}

Document 2:
{doc2[:3000]}

Comparison:"""
        
        comparison = self.llm.predict(prompt)
        
        return {
            'comparison': comparison.strip(),
            'doc1_length': len(doc1.split()),
            'doc2_length': len(doc2.split())
        }
    
    def progressive_summary(
        self,
        text: str,
        levels: int = 3
    ) -> List[Dict]:
        """
        Create progressive summaries at different detail levels
        
        Args:
            text: Text to summarize
            levels: Number of summary levels (default 3)
        
        Returns:
            List of summaries from most detailed to least
        """
        summaries = []
        current_text = text
        
        word_targets = [1000, 500, 150][:levels]
        
        for i, target in enumerate(word_targets, 1):
            result = self.summarize(
                text=current_text,
                style="detailed" if i == 1 else "concise",
                max_length=target
            )
            
            summaries.append({
                'level': i,
                'target_words': target,
                'actual_words': result['word_count'],
                'summary': result['summary']
            })
            
            # Use previous summary as input for next level
            current_text = result['summary']
        
        return summaries
    
    def sentiment_aware_summary(self, text: str) -> Dict:
        """Create a summary that includes sentiment analysis"""
        
        prompt = f"""Analyze and summarize this text, including:
1. Main content summary
2. Overall sentiment (positive/negative/neutral)
3. Key emotional themes

Text:
{text[:5000]}

Analysis:"""
        
        analysis = self.llm.predict(prompt)
        
        return {
            'summary': analysis.strip(),
            'includes_sentiment': True
        }
    
    def technical_summary(self, text: str, domain: str = "general") -> Dict:
        """Create a technical summary for specific domains"""
        
        prompt = f"""Create a technical summary for a {domain} audience.
Include technical terminology, methodologies, and specific details.

Text:
{text[:8000]}

Technical Summary:"""
        
        summary = self.llm.predict(prompt)
        
        return {
            'summary': summary.strip(),
            'domain': domain,
            'style': 'technical'
        }
    
    def layered_summary(self, text: str) -> Dict:
        """Create a multi-layered summary with different perspectives"""
        
        layers = {
            'executive': self.summarize(text, style="executive", max_length=150),
            'technical': self.technical_summary(text),
            'key_points': self.extract_key_points(text, num_points=7)
        }
        
        return {
            'executive_summary': layers['executive']['summary'],
            'technical_summary': layers['technical']['summary'],
            'key_points': layers['key_points'],
            'comprehensive': True
        }